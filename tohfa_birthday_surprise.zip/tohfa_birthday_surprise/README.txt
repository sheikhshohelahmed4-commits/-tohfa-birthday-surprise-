TOHFA BIRTHDAY SURPRISE WEBSITE
================================

FILES
- index.html: the complete mobile-friendly website.

FASTEST WAY TO PUBLISH (GitHub Pages)
1. On your phone or computer, sign in to https://github.com/ or create an account.
2. Create a new repository. Name it: tohfa-birthday-surprise
3. Set it to Public and create the repository.
4. Upload index.html using Add file -> Upload files -> Commit changes.
5. Open the repository's Settings -> Pages.
6. Under Build and deployment, select "Deploy from a branch".
7. Select branch "main" and folder "/ (root)", then Save.
8. Wait a minute or two. The Pages screen will show your public website URL, usually:
   https://YOUR-USERNAME.github.io/tohfa-birthday-surprise/
9. Open that URL on your phone to test it, then send the link to Tohfa on Messenger/WhatsApp.

MUSIC
The site intentionally does not include copyrighted music. If you have an MP3 you own or have permission to use:
1. Upload it to the same repository and name it romantic-music.mp3
2. In index.html, find the audio section and remove the HTML comment around:
   <source src="romantic-music.mp3" type="audio/mpeg">
3. Commit the change. The Play button will then work.
Browsers generally block autoplay; the visitor must tap Play.

PERSONALIZE
Open index.html and edit the letter text, date wording, and signature. Don't include private details you don't want public: GitHub Pages sites are public.
The site says "23rd Birthday Surprise"; change it if needed.
